bash run_many.sh python3 main.py --config="pg" \
                                 --env-config="c1d" with mac="distributed_mac" \
                                                         env_args.p=1.0,0.25 \
                                                         arch="lstm" \
							 rr="rudder" \ 
                                                         local_results_path="results/c1d/rudder"
